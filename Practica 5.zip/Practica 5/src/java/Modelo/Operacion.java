
package Modelo;


public class Operacion {
    public float numero1;
    public float numero2;
    public float  resultado;
    
    public Operacion(float numero1, float numero2){
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    public float suma(){
        resultado = numero1 + numero2;
        return resultado;
    }
    
    public float resta(){
        resultado = numero1 - numero2;
        return resultado;
    }
    
    public float multiplicacion(){
        resultado = numero1 * numero2;
        return resultado;
    }
    
    public float division(){
        resultado = numero1 / numero2;
        return resultado;
    }
    
    public float potencia(){
        resultado = 1f;
        for(int x = 0;x <= (numero2-1);x++){
          resultado = resultado*numero1;
        }
        
        return resultado;
    }
}
